#https://github.com/ThanhTruc23/BAI_TAP_TRI_TUE_NHAN_TAO
import tkinter as tk
from tkinter import scrolledtext
from collections import deque
import heapq


ROWS = 5
COLS = 5
CELL_SIZE = 70


initial_room = [
    [1, 0, 1, 0, 1],
    [0, 1, 0, 1, 0],
    [1, 0, 1, 0, 1],
    [0, 1, 0, 1, 0],
    [1, 0, 1, 0, 1]
]

room = []


paused = False
path = []
visited_cells = []
step_index = 0
current_algorithm = ""


# GIAO DIỆN CHÍNH

root = tk.Tk()

root.title("MÁY HÚT BỤI - BFS DFS IDS UCS")
root.geometry("1600x900")
root.configure(bg="#0F172A")



menu_frame = tk.Frame(
    root,
    bg="#111827",
    width=240
)

menu_frame.pack(side="left", fill="y")

title_menu = tk.Label(
    menu_frame,
    text="MENU",
    font=("Arial", 26, "bold"),
    bg="#111827",
    fg="#38BDF8"
)

title_menu.pack(pady=30)


center_frame = tk.Frame(
    root,
    bg="#0F172A"
)

center_frame.pack(
    side="left",
    fill="both",
    expand=True
)


demo_label = tk.Label(
    center_frame,
    text="DEMO",
    font=("Arial", 24, "bold"),
    bg="#0F172A",
    fg="#F8FAFC"
)

demo_label.pack(pady=10)

canvas = tk.Canvas(
    center_frame,
    width=420,
    height=420,
    bg="#1E293B",
    bd=0,
    highlightthickness=4,
    highlightbackground="#38BDF8"
)

canvas.pack(pady=10)


button_frame = tk.Frame(
    center_frame,
    bg="#0F172A"
)

button_frame.pack(pady=10)


solution_label = tk.Label(
    center_frame,
    text="GIẢI PHÁP CUỐI CÙNG",
    font=("Arial", 20, "bold"),
    bg="#0F172A",
    fg="#38BDF8"
)

solution_label.pack(pady=10)

solution_text = tk.Text(
    center_frame,
    width=80,
    height=12,
    font=("Consolas", 11),
    bg="#111827",
    fg="white",
    bd=0,
    insertbackground="white"
)

solution_text.pack(pady=5)


right_frame = tk.Frame(
    root,
    bg="#111827",
    width=350
)

right_frame.pack(side="right", fill="y")

activity_label = tk.Label(
    right_frame,
    text="QT HOẠT ĐỘNG",
    font=("Arial", 22, "bold"),
    bg="#111827",
    fg="#38BDF8"
)

activity_label.pack(pady=20)


activity_text = scrolledtext.ScrolledText(
    right_frame,
    width=40,
    height=42,
    font=("Consolas", 10),
    bg="#0F172A",
    fg="white",
    bd=0,
    insertbackground="white"
)

activity_text.pack(padx=10, pady=10)


def reset_room():

    global room
    global visited_cells

    room = [row[:] for row in initial_room]

    visited_cells = []


def draw_room(robot_x=None, robot_y=None):

    canvas.delete("all")

    for i in range(ROWS):

        for j in range(COLS):

            x1 = j * CELL_SIZE
            y1 = i * CELL_SIZE

            x2 = x1 + CELL_SIZE
            y2 = y1 + CELL_SIZE

            # Ô đã đi qua
            if (i, j) in visited_cells:
                color = "#22C55E"

            # Ô bẩn
            elif room[i][j] == 1:
                color = "#EF4444"

            # Ô sạch
            else:
                color = "#E2E8F0"

            canvas.create_rectangle(
                x1,
                y1,
                x2,
                y2,
                fill=color,
                outline="#0F172A",
                width=3
            )

            
            if i == robot_x and j == robot_y:

                # THÂN MÁY HÚT BỤI
                canvas.create_oval(
                    x1 + 10,
                    y1 + 10,
                    x2 - 10,
                    y2 - 10,
                    fill="#2C2C2C",
                    outline="#D9D9D9",
                    width=3
                )

                # VIỀN TRONG
                canvas.create_oval(
                    x1 + 18,
                    y1 + 18,
                    x2 - 18,
                    y2 - 18,
                    fill="#4B5563",
                    outline="#9CA3AF",
                    width=2
                )

                # NÚT NGUỒN
                canvas.create_oval(
                    x1 + 26,
                    y1 + 26,
                    x1 + 34,
                    y1 + 34,
                    fill="#22C55E",
                    outline="white"
                )

                # CHỔI QUÉT TRÁI
                canvas.create_line(
                    x1 + 8,
                    y1 + 45,
                    x1 + 2,
                    y1 + 55,
                    fill="#FACC15",
                    width=2
                )

                # CHỔI QUÉT PHẢI
                canvas.create_line(
                    x2 - 8,
                    y1 + 45,
                    x2 + 2,
                    y1 + 55,
                    fill="#FACC15",
                    width=2
                )

# BFS

def bfs():

    queue = deque([(0, 0)])

    visited = set()

    result = []

    while queue:

        x, y = queue.popleft()

        if (x, y) in visited:
            continue

        visited.add((x, y))

        result.append((x, y))

        directions = [
            (0, 1),
            (1, 0),
            (0, -1),
            (-1, 0)
        ]

        for dx, dy in directions:

            nx = x + dx
            ny = y + dy

            if 0 <= nx < ROWS and 0 <= ny < COLS:

                if (nx, ny) not in visited:
                    queue.append((nx, ny))

    return result

# DFS

def dfs():

    stack = [(0, 0)]

    visited = set()

    result = []

    while stack:

        x, y = stack.pop()

        if (x, y) in visited:
            continue

        visited.add((x, y))

        result.append((x, y))

        directions = [
            (-1, 0),
            (0, -1),
            (1, 0),
            (0, 1)
        ]

        for dx, dy in directions:

            nx = x + dx
            ny = y + dy

            if 0 <= nx < ROWS and 0 <= ny < COLS:

                if (nx, ny) not in visited:
                    stack.append((nx, ny))

    return result


# IDS

def dls(node, depth, visited, result):

    x, y = node

    if depth < 0:
        return

    if node in visited:
        return

    visited.add(node)

    result.append(node)

    directions = [
        (0, 1),
        (1, 0),
        (0, -1),
        (-1, 0)
    ]

    for dx, dy in directions:

        nx = x + dx
        ny = y + dy

        if 0 <= nx < ROWS and 0 <= ny < COLS:

            dls((nx, ny), depth - 1, visited, result)

def ids():

    result = []

    for depth in range(ROWS * COLS):

        visited = set()

        temp = []

        dls((0, 0), depth, visited, temp)

        for node in temp:

            if node not in result:
                result.append(node)

    return result


# UCS

def ucs():

    pq = []

    heapq.heappush(pq, (0, (0, 0)))

    visited = set()

    result = []

    while pq:

        cost, (x, y) = heapq.heappop(pq)

        if (x, y) in visited:
            continue

        visited.add((x, y))

        result.append((x, y))

        directions = [
            (0, 1),
            (1, 0),
            (0, -1),
            (-1, 0)
        ]

        for dx, dy in directions:

            nx = x + dx
            ny = y + dy

            if 0 <= nx < ROWS and 0 <= ny < COLS:

                if (nx, ny) not in visited:

                    heapq.heappush(
                        pq,
                        (cost + 1, (nx, ny))
                    )

    return result

# GIẢI PHÁP

def show_solution():

    solution_text.delete(1.0, tk.END)

    solution_text.insert(
        tk.END,
        f"THUẬT TOÁN: {current_algorithm}\n\n"
    )

    solution_text.insert(
        tk.END,
        f"SỐ BƯỚC: {len(path)}\n\n"
    )

    solution_text.insert(
        tk.END,
        "ĐƯỜNG ĐI:\n"
    )

    for step in path:

        solution_text.insert(
            tk.END,
            f"{step} -> "
        )

    solution_text.insert(
        tk.END,
        "\n\nRobot đã làm sạch toàn bộ phòng."
    )

# DEMO

def run_demo():

    global step_index

    if paused:
        return

    if step_index >= len(path):

        show_solution()

        return

    x, y = path[step_index]

    visited_cells.append((x, y))

    if room[x][y] == 1:
        room[x][y] = 0

    draw_room(x, y)

    activity_text.insert(
        tk.END,
        f"Bước {step_index + 1}: "
        f"({x},{y})\n"
    )

    activity_text.see(tk.END)

    step_index += 1

    root.after(500, run_demo)

def start_algorithm(algo):

    global path
    global paused
    global step_index
    global current_algorithm

    current_algorithm = algo

    reset_room()

    activity_text.delete(1.0, tk.END)

    step_index = 0

    paused = False

    if algo == "BFS":
        path = bfs()

    elif algo == "DFS":
        path = dfs()

    elif algo == "IDS":
        path = ids()

    elif algo == "UCS":
        path = ucs()

    run_demo()


def pause_demo():

    global paused

    paused = True


def resume_demo():

    global paused

    paused = False

    run_demo()


btn_style = {
    "font": ("Arial", 13, "bold"),
    "width": 16,
    "height": 2,
    "bg": "#2563EB",
    "fg": "white",
    "bd": 0,
    "activebackground": "#38BDF8",
    "cursor": "hand2"
}


bfs_btn = tk.Button(
    menu_frame,
    text="BFS",
    command=lambda: start_algorithm("BFS"),
    **btn_style
)

bfs_btn.pack(pady=15)

dfs_btn = tk.Button(
    menu_frame,
    text="DFS",
    command=lambda: start_algorithm("DFS"),
    **btn_style
)

dfs_btn.pack(pady=15)

ids_btn = tk.Button(
    menu_frame,
    text="IDS",
    command=lambda: start_algorithm("IDS"),
    **btn_style
)

ids_btn.pack(pady=15)

ucs_btn = tk.Button(
    menu_frame,
    text="UCS",
    command=lambda: start_algorithm("UCS"),
    **btn_style
)

ucs_btn.pack(pady=15)


run_btn = tk.Button(
    button_frame,
    text="CHẠY",
    font=("Arial", 12, "bold"),
    bg="#22C55E",
    fg="white",
    width=12,
    bd=0,
    command=resume_demo
)

run_btn.grid(row=0, column=0, padx=10)


pause_btn = tk.Button(
    button_frame,
    text="DỪNG",
    font=("Arial", 12, "bold"),
    bg="#EF4444",
    fg="white",
    width=12,
    bd=0,
    command=pause_demo
)

pause_btn.grid(row=0, column=1, padx=10)

#
reset_room()
draw_room()


root.mainloop()