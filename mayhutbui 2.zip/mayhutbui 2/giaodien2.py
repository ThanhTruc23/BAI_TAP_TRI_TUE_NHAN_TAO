import tkinter as tk
from collections import deque
import heapq

ROWS = 5
COLS = 5
CELL_SIZE = 60

initial_room = [
    ["Bẩn", "Sạch", "Bẩn", "Sạch", "Bẩn"],
    ["Sạch", "Bẩn", "Sạch", "Bẩn", "Sạch"],
    ["Bẩn", "Sạch", "Bẩn", "Sạch", "Bẩn"],
    ["Sạch", "Bẩn", "Sạch", "Bẩn", "Sạch"],
    ["Bẩn", "Sạch", "Bẩn", "Sạch", "Bẩn"]
]

room = []
path = []
visited_cells = []
step_index = 0
current_algorithm = ""

def get_neighbors(x, y):
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
    neighbors = []
    for dx, dy in directions:
        nx, ny = x + dx, y + dy
        if 0 <= nx < ROWS and 0 <= ny < COLS:
            neighbors.append((nx, ny))
    return neighbors

def find_path_bfs(start, goal):
    queue = deque([[start]])
    visited = {start}
    while queue:
        curr_path = queue.popleft()
        x, y = curr_path[-1]
        if (x, y) == goal:
            return curr_path
        for neighbor in get_neighbors(x, y):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(curr_path + [neighbor])
    return [start]

def find_path_dfs(start, goal):
    stack = [[start]]
    visited = {start}
    while stack:
        curr_path = stack.pop()
        x, y = curr_path[-1]
        if (x, y) == goal:
            return curr_path
        for neighbor in reversed(get_neighbors(x, y)):
            if neighbor not in visited:
                visited.add(neighbor)
                stack.append(curr_path + [neighbor])
    return [start]

def find_path_ucs(start, goal):
    pq = [(0, [start])]
    visited = {}
    while pq:
        cost, curr_path = heapq.heappop(pq)
        state = curr_path[-1]
        if state == goal:
            return curr_path
        if state in visited and visited[state] <= cost:
            continue
        visited[state] = cost
        for neighbor in get_neighbors(*state):
            heapq.heappush(pq, (cost + 1, curr_path + [neighbor]))
    return [start]

def find_path_ids(start, goal):
    def dls(curr_path, depth):
        state = curr_path[-1]
        if state == goal: return curr_path
        if depth <= 0: return None
        for neighbor in get_neighbors(*state):
            if neighbor not in curr_path:
                res = dls(curr_path + [neighbor], depth - 1)
                if res: return res
        return None
    for depth in range(ROWS * COLS):
        res = dls([start], depth)
        if res: return res
    return [start]

def generate_full_cleaning_path(algo_type):
    current_pos = (0, 0)
    full_path = [current_pos]
    temp_room = [row[:] for row in initial_room]
    
    while True:
        dirty_cells = [(r, c) for r in range(ROWS) for c in range(COLS) if temp_room[r][c] == "Bẩn"]
        if not dirty_cells:
            break
            
        nearest_dirty = min(dirty_cells, key=lambda p: abs(p[0]-current_pos[0]) + abs(p[1]-current_pos[1]))
        
        if algo_type == "BFS": sub_path = find_path_bfs(current_pos, nearest_dirty)
        elif algo_type == "DFS": sub_path = find_path_dfs(current_pos, nearest_dirty)
        elif algo_type == "UCS": sub_path = find_path_ucs(current_pos, nearest_dirty)
        elif algo_type == "IDS": sub_path = find_path_ids(current_pos, nearest_dirty)
        else: sub_path = [current_pos]
            
        if len(sub_path) > 1:
            full_path.extend(sub_path[1:])
            
        current_pos = nearest_dirty
        temp_room[current_pos[0]][current_pos[1]] = "Sạch"
        
    return full_path

def reset_room():
    global room, visited_cells, step_index, path
    room = [row[:] for row in initial_room]
    visited_cells = []
    path = []
    step_index = 0
    draw_room()
    log_box.delete(1.0, tk.END)

def draw_room(robot_x=None, robot_y=None):
    canvas.delete("all")
    for i in range(ROWS):
        for j in range(COLS):
            x1, y1 = j * CELL_SIZE, i * CELL_SIZE
            x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
            
            if i == robot_x and j == robot_y: color = "lightblue"
            elif (i, j) in visited_cells: color = "lightgreen"
            elif room[i][j] == "Bẩn": color = "orange"
            else: color = "white"
                
            canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="gray")
            
            if room[i][j] == "Bẩn": text_val = "Bẩn"
            elif (i, j) in visited_cells: text_val = "Sạch"
            else: text_val = f"({i},{j})"
            canvas.create_text((x1+x2)/2, (y1+y2)/2, text=text_val, fill="black", font=("Arial", 9))

def start_algorithm(algo):
    global path, current_algorithm
    reset_room()
    current_algorithm = algo
    info_label.config(text=f"Thuật toán: {algo}")
    path = generate_full_cleaning_path(algo)
    animate()

def animate():
    global step_index
    if step_index < len(path):
        x, y = path[step_index]
        if (x, y) not in visited_cells:
            visited_cells.append((x, y))
            
        room[x][y] = "Sạch"
        draw_room(x, y)
        
        log_box.insert(tk.END, f"Bước {step_index+1:02d}: Đi tới ({x},{y})\n")
        log_box.see(tk.END)
        
        step_index += 1
        root.after(300, animate)
    else:
        info_label.config(text=f"Thuật toán: {current_algorithm} - HOÀN THÀNH ({len(path)} bước)")

root = tk.Tk()
root.title("Mô phỏng Máy hút bụi")

top_frame = tk.Frame(root)
top_frame.pack(pady=10)

tk.Button(top_frame, text="Chạy BFS", command=lambda: start_algorithm("BFS"), width=10).pack(side="left", padx=5)
tk.Button(top_frame, text="Chạy DFS", command=lambda: start_algorithm("DFS"), width=10).pack(side="left", padx=5)
tk.Button(top_frame, text="Chạy UCS", command=lambda: start_algorithm("UCS"), width=10).pack(side="left", padx=5)
tk.Button(top_frame, text="Chạy IDS", command=lambda: start_algorithm("IDS"), width=10).pack(side="left", padx=5)

info_label = tk.Label(root, text="Bấm một thuật toán phía trên để bắt đầu dọn dẹp", font=("Arial", 11, "bold"))
info_label.pack(pady=5)

main_frame = tk.Frame(root)
main_frame.pack(pady=10, padx=10)

canvas = tk.Canvas(main_frame, width=COLS*CELL_SIZE, height=ROWS*CELL_SIZE, bg="white")
canvas.pack(side="left", padx=10)

log_box = tk.Text(main_frame, width=25, height=14)
log_box.pack(side="right", padx=10)

reset_room()
root.mainloop()